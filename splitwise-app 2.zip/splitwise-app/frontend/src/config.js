const apiHost = 'http://localhost:3001';

export default apiHost;
